#!/usr/bin/env python
# -*- coding: utf-8 -*-

from math import *

if __name__ == '__main__':
    import clime
    clime.main()
