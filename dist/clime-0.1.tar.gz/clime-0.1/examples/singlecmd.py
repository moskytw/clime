#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''Here is docstring of module.'''

def onlyme(s, b=True, l=None):
    '''Here is docstring of function.'''

    print 's:', s
    print 'b:', b
    print 'l:', l

if __name__ == '__main__':
    import clime
    clime.main()
